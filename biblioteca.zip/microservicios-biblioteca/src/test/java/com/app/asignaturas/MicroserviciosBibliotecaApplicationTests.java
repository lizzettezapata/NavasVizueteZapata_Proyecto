package com.app.asignaturas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviciosBibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
